# DatabaseWithAngular
Working With MySQL Database in AngularJS

### Follow these steps to use this project:
1. Clone project files into your server directory
2. Upload project.sql file into your server
3. Change your username and password in 'config.php' inside /js directory.
4. Launch the project and you're good to go on...

### Feature:
1. Add Data into mysql database
2. Remove Data from mysql database
3. Search content
